Sauerbraten remake of Aerowalk by foldl.

The original QuakeWorld map is credited to Mattias Konradsson "Preacher".

Like the Quake version, this map is intended for dueling and maybe 2v or 3v teamplay.

